package com.restservice.recipeAndMealPlanning.inventory;

public class InventoryController {
}
